# Changelog

All notable changes to the `spectra` extension are documented here. This project follows
[Semantic Versioning](https://semver.org/).

## [1.29.0] - 2026-10-25

Every agent's descriptions now come from one source, so the copies a user sees agree.

### Changed
- **Each command's description is the same everywhere.** The `description:` line in each command file's
  front matter now matches its entry in `extension.yml`; thirteen command files had drifted. Both are
  rendered from the agent's file under `agents/` in the repository.
- **The extension README's per-agent sections are regenerated** from the same source as `AGENTS_LIST.md`,
  so the two carry identical text. Each section now opens with the agent's lead paragraph, then its
  arguments, when to use it, and examples, followed by the guides that were in the README before —
  including each agent's step-by-step *How it works* and its re-run and upgrade notes.
- No command's behavior changes.

## [1.28.0] - 2026-10-25

UAT finds its feature the way the implement command does, so its ticks land in the feature that was just
built and the after-implement offer needs no path.

### Changed
- **`speckit.spectra.uat` resolves the feature as Spec Kit's implement command does.** The project root
  is `SPECIFY_INIT_DIR` or the nearest `.specify/`; the feature directory is `SPECIFY_FEATURE_DIRECTORY`,
  then `feature_directory` in `.specify/feature.json`; a set-but-empty variable is unset; the directory
  must hold a `tasks.md`. It never uses the branch name, modification times, a listing of `specs/`, or
  session history, offers no picker, and never writes the feature record or creates a directory. The
  resolved feature and its source are announced first, named again in the run confirmation, and recorded
  in `uat-report.md` and the session report. Ticks, evidence, and the report go to that feature even if
  the record changes mid-run.
- **The path argument is optional, and a path naming a feature other than the active one now stops.**
  Anyone who scripted the old required-path form gets a stop before anything is started: the run writes
  nothing and names both directories, the source, and the two ways to switch — set
  `SPECIFY_FEATURE_DIRECTORY` for the session, or change `feature_directory` in `.specify/feature.json`
  for good. A path to the active feature directory or its `spec.md` still works as a confirmation.
- **One read-only shell read** of `SPECIFY_INIT_DIR` and `SPECIFY_FEATURE_DIRECTORY`, once per run,
  before the run confirmation. It starts no build, server, or process, so "nothing is started before the
  run confirmation" still holds. If it is denied or fails, the run stops rather than fall back to
  `.specify/feature.json` alone.
- **The after-implement offer now needs no path.** This closes the candidate noted in 1.27.0; the hook
  prompt itself is unchanged.

## [1.27.0] - 2026-10-25

The test plan finds its feature the way the planning command does, so `test-plan.md` and `plan.md` always
share a directory and the approved obligations reach the tasks.

### Changed
- **`speckit.spectra.test-plan` resolves the feature as Spec Kit's planning command does.** The project
  root is `SPECIFY_INIT_DIR` or the nearest `.specify/`; the feature directory is
  `SPECIFY_FEATURE_DIRECTORY`, then `feature_directory` in `.specify/feature.json`; a set-but-empty
  variable is unset; the specification is that directory's `spec.md`. It never uses the branch name,
  modification times, a listing of `specs/`, or session history, offers no picker, and never writes the
  feature record or creates a directory. The resolved feature and its source are announced first and
  recorded in the identifying block and the report.
- **The path argument is optional, and a path naming a feature other than the active one now stops.**
  Anyone who scripted the old required-path form gets a stop, not a silent split: the run writes nothing
  and names both directories, the source, and the two ways to switch — set `SPECIFY_FEATURE_DIRECTORY`
  for the session, or change `feature_directory` in `.specify/feature.json` for good. A path to the active
  feature directory or its `spec.md` still works as a confirmation.
- **One read-only shell read** of `SPECIFY_INIT_DIR` and `SPECIFY_FEATURE_DIRECTORY`, once per run, is the
  only command run to resolve the feature. If it is denied or fails, the run stops rather than fall back
  to `.specify/feature.json` alone. A `SPECIFY_INIT_DIR` that names another project trips the
  out-of-project stop.
- **The planning handoff is printed only when the planning command would resolve the same directory** —
  checked again just before printing, so a parallel `specify` cannot redirect it.
- **The after-specify hook no longer passes a path**; the run uses the feature specify just recorded.
- `speckit.spectra.uat` still requires an explicit feature path. It is a candidate for the same change and
  is unchanged here.

## [1.26.0] - 2026-10-24

The ADR agent becomes the fifth constitution feeder: a significant decision reaches the constitution
through `/speckit-constitution`, never by the agent editing it.

### Changed
- **`speckit.spectra.adr` never writes `.specify/memory/constitution.md`.** Step 7 used to offer the edit
  and make it on agreement, which skipped the version bump, the sync impact report, and the propagation
  `/speckit-constitution` owns. A significant decision now gets drafted guardrails as records with frozen
  `adr-NNN-<section-slug>-<hash>` IDs, one approval step outside the five clarifying questions (approve,
  revise the ADR first, talk it through, decline all; silence adopts nothing), and two sections added to
  the ADR it just wrote: **Constitution guardrails** (every record offered) and **Constitution input**
  (only the accepted ones). It prints one `/speckit-constitution` amend line naming the ADR's resolved
  path and asking for the ADR to be cited as the source. Nothing accepted, no line. With no constitution
  the goal is `pending`: the records are kept, no line is printed, and the domain analyzer is named first.
  A non-significant ADR gets no section, and a template without these headings has them appended. Step 8
  no longer suggests staging the constitution.
- **The ADR agent drafts only on its own ground** — architecture-level choices, and architectural decisions
  on security, data handling, or reliability. Testing, deployment, languages / frameworks / dependency
  policy, the domain, and methodology are referred to the agent that owns them, with a re-run suggested.
  A superseding ADR drafts `amends:` against the principle its predecessor introduced, and a `Superseded`
  or `Deprecated` ADR's records never constrain.
- **`domain-analyzer` shares that ground clause by clause.** Every lens except Technology & dependency
  policy cites an accepted ADR record that covers a clause instead of drafting it, reading only ADRs whose
  status is `Proposed` or `Accepted`. Technology & dependency policy stays its alone.
- **`methodology` lists the ADR agent as a fifth feeder** in its sibling-ground table, and keeps it out of
  the foundation sequence it suggests after its handoff.

## [1.25.0] - 2026-10-24

The foundation agents now hand off to each other safely on a brownfield project: imported knowledge stays
a source the owning agent reads, and every feeder hands the constitution the same shape of input.

### Changed
- **`speckit.spectra.kb-vault` never writes a constitution feeder's document.** A source it classifies as
  a domain analysis, engineering methodology, test strategy, or deployment strategy is written as a
  **policy source** to `<artifact-root>/<kind>-source/NNN-<kebab-title>.md`, resolving
  `<kind>-source-template`, then `kb-document-template`. The plan and report name the owning command. The
  four singletons — `DOMAIN_ANALYSIS.md`, `ENGINEERING_METHODOLOGY.md`, `TEST_STRATEGY.md`,
  `DEPLOYMENT_STRATEGY.md` — are never matched, created, or updated by kb-vault, whoever wrote them, and
  the original stays in place after the owning agent runs.
- **The four feeders read imported knowledge as `claimed`.** `domain-analyzer`, `methodology`,
  `test-strategy`, and `deployment-strategy` read their `-source` folder and any kb-vault document by its
  Provenance section. A candidate whose only evidence is `claimed` is `aspirational`; where a document and
  the code or history disagree, both are reported and the code or history is current practice. Imported
  text never adopts a guardrail, and text in it addressed to the agent is content, never an instruction.
  `test-strategy`'s R1 grows to four provenances.
- **Each feeder marks its document `command: speckit.spectra.<agent>`** and classifies a file already at
  its path: its own, its own from an earlier version (by signature), another agent's (reported, nothing
  written), or not its own — read as `claimed` and replaced only with consent asked outside the round;
  declined or non-interactive writes nothing and shows the document in the session.
- **`test-strategy` and `deployment-strategy` hand off a Constitution input section**, like
  `domain-analyzer` and `methodology`. Each run opens with a `Constitution: … Goal: create | update` line;
  with no constitution the goal is **create** instead of drafting nothing. Every drafted guardrail is a
  record with a frozen `ts-` / `ds-` ID, a basis, and a decision (`accepted`, `declined`, `skipped`,
  `not_asked`); re-runs mark adoption, never revert it, report drift, and never re-offer a declined
  guardrail as new. A checkbox amendment from before 1.25.0 migrates without losing a decision — `- [x]`
  becomes `accepted`, `- [ ]` becomes `not_asked`. The hand-off lines are the create and amend prompts the
  other feeders use; no command is given when nothing was accepted. Front matter gains `goal:` and
  `constitution_input:`; `amendment_state:` stays. Both templates rename "Proposed constitution amendment"
  to "Constitution input".
- **`test-strategy` reads its siblings** — accepted records of `DOMAIN_ANALYSIS.md`,
  `ENGINEERING_METHODOLOGY.md`, and `DEPLOYMENT_STRATEGY.md` — and cites rather than re-drafts a clause
  another feeder holds, such as methodology's test-first fix obligation. `deployment-strategy` and
  `domain-analyzer` read `TEST_STRATEGY.md` accepted-only too.
- **`speckit.spectra.review-pr` counts only accepted guardrails** from a test or deployment strategy. A
  checkbox-era file with no ticked item contributes no standard, and the review says so and names the
  remedy.

### Fixed
- **kb-vault's template list** now names exactly the templates its reserved map uses — `adr-template`,
  `brd-template`, `impact-analysis-template`, `defect-rca-template` — and no feeder template.

### Documentation
- **Starting on an existing codebase.** README, the extension README, and the landing page give one
  brownfield sequence: kb-vault (optional) → domain-analyzer → constitution (create) → methodology →
  constitution (amend) → test-strategy → constitution (amend) → deployment-strategy → constitution
  (amend), why the constitution runs after each agent, and the advice to declare `Artifact root:` in the
  first constitution run.

## [1.24.0] - 2026-10-24

### Added
- **`speckit.spectra.methodology` — the Methodology Analyst.** A foundation-phase agent that finds,
  chooses, and records the team's engineering methodology, and hands it to the constitution. It follows the
  shape of `domain-analyzer` and `test-strategy`: read, ask, then write once.
  - **The mode and goal come first.** Brownfield or greenfield, from three named signals — source beyond
    scaffolding, workflow configuration, more than 10 commits — with a mixed reading settled by the team
    before any lens is worked; and whether the constitution will be created or updated.
  - **Nine fixed lenses**: methodology stack, work modes & classification, requirements intake, spec
    lifecycle & traceability, branching & integration, review & merge gates, change records, AI
    collaboration rules, governance & evolution. Brownfield lenses report current practice with citations
    first; greenfield lenses offer defaults, all `aspirational`.
  - **Spec-driven development is the base.** TDD, BDD/ATDD, DDD, contract-first, and ADR-driven are offered
    as overlays with their evidence, and enter the constitution only as obligations bound to a spec-kit
    phase, from a closed obligations matrix. TDD's implement obligation is checked in `tasks.md`: the test
    task records a failing run before its implementation task is ticked. Each overlay carries a strictness
    and a scope, and an unpractised one binds new and changed code by default.
  - **Ten questions, one per turn**, each with at least four options, one recommended, one Skip. Lens 8
    offers three autonomy levels for AI agents, every phase a human checkpoint recommended.
  - **One file**, `<artifact-root>/ENGINEERING_METHODOLOGY.md`, written after the round: onboarding-grade,
    with a mode-choice table, branch-naming and commit-prefix references, the obligations matrix, a
    Constitution input section, and Decisions and sources. A hand-written file already there is read as
    evidence and replaced only with consent.
  - **Sibling ground is referred, never proposed**: testing to `test-strategy`, environments, versioning,
    and releases to `deployment-strategy`, product technology and domain content to `domain-analyzer`.
- **`engineering-methodology-template`**, overridable at
  `.specify/templates/overrides/engineering-methodology-template.md`.

### Changed
- **`domain-analyzer` hands Delivery & workflow to `methodology`.** Six lenses and seven questions.
  Delivery & workflow records from an earlier run are kept under "Handed on to
  `speckit.spectra.methodology`", leave the Constitution input section, and are never deleted; the
  methodology agent reads them as prior answers.
- **`deployment-strategy` no longer proposes the branching model.** Its Release & versioning lens keeps how
  a release is cut, the versioning scheme, and the hotfix promotion path, and cites
  `ENGINEERING_METHODOLOGY.md` for the branching model.
- **`kb-vault` routes an absorbed methodology to `ENGINEERING_METHODOLOGY.md`** through its reserved map,
  and refers it on, never updating, when that file was written by the methodology agent. Its report gains
  a "Sources referred on" item.
- **`review-pr` reads `ENGINEERING_METHODOLOGY.md` as a T2 standard**, citing accepted guardrails only.

## [1.23.0] - 2026-10-23

### Changed
- **`domain-analyzer` is interactive and exists to feed the constitution.** It now follows the same shape
  as `test-strategy`: read, ask, then write once.
  - **The goal comes first.** The run opens by saying whether `.specify/memory/constitution.md` exists, and
    so whether this analysis will **create** the constitution or **update** it. The goal is carried into
    the document and into the handoff.
  - **Seven fixed lenses**, each feeding a constitution section: domain & business rules, data sensitivity
    & regulation, security & trust boundaries, architecture & boundaries, technology & dependency policy,
    reliability & operability, delivery & workflow. No lens is ever omitted; one with nothing to propose
    says what was searched. Testing and deployment policy are referred to `test-strategy` and
    `deployment-strategy` rather than proposed twice.
  - **Every candidate says whether the code already follows it** — `observed` or `aspirational` — so an SME
    on a brownfield project can see which guardrails create debt the day they are ratified.
  - **Eight questions, one per turn**: the domain, then one per lens. Each offers at least four options —
    recommended set, codify only what exists, full set, Skip — with exactly one recommended, and free text
    always valid. "Use your defaults" takes every recommendation.
  - **Only a human choice adopts.** Skip, an unanswered question, and `--non-interactive` adopt nothing.
  - **The file is written once, after the round**, to the same `<artifact-root>/DOMAIN_ANALYSIS.md`. It
    records every candidate with its decision (`accepted`, `declined`, `skipped`, `not_asked`) and gathers
    the accepted, not-yet-adopted ones into a **Constitution input** section.
  - **The handoff is worded for the goal**: a create prompt or an amend prompt for `/speckit-constitution`,
    or none when nothing was accepted. The command still never writes the constitution or invokes that
    command.
  - **Re-runs** pre-fill each question with the previous answer, never re-offer a declined candidate, keep
    frozen IDs, and mark accepted items the constitution now carries as `adopted`.
- **Earlier checkbox files are read, not lost.** A pre-1.23.0 `DOMAIN_ANALYSIS.md` (or
  `.specify/memory/domain-analysis.md`) is read as prior decisions — ticked is accepted, unticked is
  undecided and asked again, since an unticked box cannot say whether anyone reviewed it — and rewritten in
  the new format.
- **`review-pr` and `deployment-strategy` use only accepted guardrails from a domain analysis.** The
  analysis now records the guardrails an SME declined or skipped as well as the ones they accepted; only
  `accepted` entries are a standard a review may raise a finding against, or a constraint that may shape a
  deployment gate. In an earlier checkbox file, only ticked items count.
- **`domain-analysis-template`** has new sections: constitution status and goal, inferred domain, one per
  lens, Constitution input, and decisions and sources. A project override written for the checkbox format
  still resolves; the command writes the Constitution input section even when an override omits it.

## [1.22.0] - 2026-10-16

### Changed
- **`review-pr` measures a change against a fixed standards chain**, not only the constitution. It reads,
  at the base revision: the constitution and ADRs (T1); the supporting documents Spectra's own agents
  write, plus the contributor guide (T2: `TEST_STRATEGY.md`, `DEPLOYMENT_STRATEGY.md`,
  `DOMAIN_ANALYSIS.md`, `CONTRIBUTING.md`, at the project's artifact root and their earlier locations);
  the codebase's own conventions (T3); and the **Spectra baseline** (T4), seven principles B1–B7 that
  findings cite by ID. The highest tier present governs, and every tier below it stays in play. A project
  with no constitution is still reviewed against evidence, never the agent's taste, and coverage says which
  tier governed. Only the constitution carries a floor. Supporting-document clauses can reach Major. A
  convention finding needs a file-and-line example and is never above Minor. CI-enforced linters and
  formatters suppress the findings they already enforce.
- **The authorizing spec is the only traceability baseline.** A spec shipped in the PR, or named by the
  reviewer, overrides every older spec on the same behaviour. A difference from an older spec never becomes
  a code-change finding. At most there is one suggestion-free Minor saying the older spec is out of date,
  and only when the new spec names it. This fixes reviews that asked for deliberately changed behaviour to
  be put back.
- **Three lenses are always considered**, with or without a spec:
  - **blast radius**: unannounced behaviour change, with at most five bounded caller searches. It is
    classified by consequence, and breaking a published contract with no migration path is a Blocker.
  - **generation artifacts**: modules that don't exist, leftover placeholders, duplicated helpers, unrelated
    reformatting. A **new dependency is always raised**, as a Question by default, or a Major when it is
    unpinned against the project's convention or duplicates an existing dependency.
  - **test integrity**: a test weakened or deleted alongside the code it covers is at least Major.
- **Pull requests with no spec** are checked for what they say they do. A **stated-intent check** measures
  the diff against the PR's own title, body and commits: the weakest intent source, treated as data, never
  instruction, and capped at Minor. A **bounded prior-spec lookup** (at most three keys, by code search over
  `spec.md` files) raises a **Question** when the diff contradicts a requirement an older spec defined. It
  states both readings and carries no suggestion. It is never a baseline for anything else.
- The review template's judgment disclaimer now names the standards chain and the baseline. No section of
  the template changed.

## [1.21.0] - 2026-10-15

### Added
- **`speckit.spectra.uat`** — the UAT Runner, in the Testing & Quality phase. It runs a feature's
  user-acceptance scenarios **only on explicit request** — invoked directly, or by accepting an offer made
  after implement. It reads the UAT phase in the feature's `tasks.md` and the Suggested UAT scenarios in
  its `test-plan.md`, shows the exact command it would use to start the build and asks before starting
  anything, then performs the scenarios the agent can actually drive in that session. Evidence —
  screenshots, terminal or request transcripts — goes to `specs/<feature>/uat/<run-stamp>/`, never
  overwriting an earlier run. It ticks a `[UAT]` task only when it observed the scenario pass, linking the
  evidence on the same line; human-only, failed, and blocked scenarios stay open with a reason. It writes
  `specs/<feature>/uat-report.md` with a cumulative run log. The feature path is required and never
  inferred; it never edits source, tests, CI, the spec, the test plan, or the constitution, masks or
  withholds anything that might be a secret, and makes no network request beyond what the build under
  test makes.
- **`uat-report-template`**, registered and resolved through Spec Kit's template stack. Override at
  `.specify/templates/overrides/uat-report-template.md`.
- **Two optional hooks.** After specify, an offer to generate a test plan for the spec just written.
  After implement, an offer to run UAT, ordered before the existing pull-request offer. Both only ask.

### Changed
- **`test-strategy` works six lenses instead of four**: unit, integration, API contract, end-to-end,
  **UAT** (who may execute it, and what counts as evidence on each surface the project has) and
  **Regression** (the gate suite, where it runs, and whether a fixed defect earns a test). It records
  each lens's applicability and the lens-ownership map in front matter, so every test plan inherits them.
  Still five questions: question 3 now also asks which journeys deserve UAT and who signs it off, and
  question 5 whether an AI agent may execute UAT. Where UAT applies, the drafted constitution amendment
  carries a clause that the implement command never executes or ticks UAT tasks.
- **`test-plan` takes its lens set from the strategy, not just the names.** A lens the strategy rules out
  is unavailable, and a criterion that only it could verify is listed as "ruled out by the strategy". A
  strategy that predates UAT and regression, or no strategy at all, is said loudly. Two new sections:
  **Suggested UAT scenarios** (every user story gets one or a reason; executor `agent`, `human`, or
  `either`) and **Regression scope** (the existing tests that must stay green, cited). It now honours the
  strategy's ownership map, ruled-out tools, known risk areas, favoured journeys, per-surface floors, and
  provenance, and flags a strategy that looks stale.
- **`test-plan`'s handoff writes into `plan.md`.** The printed planning prompt links the written test
  plan and asks for a "Testing obligations" section in `plan.md` — which the core tasks command reads —
  so the tasks include tests at the assigned levels, keep the regression scope green, and end with a UAT
  phase that the implement command does not execute.

### Fixed
- `test-plan`'s spec-resolution step said "Four outcomes" and listed six.

### Upgrading
- Re-run `speckit.spectra.test-strategy` to add the UAT and Regression lenses to an existing
  `TEST_STRATEGY.md`. Until then, test plans omit both sections and say why.

### Governance
- Spectra's own constitution (1.11.0) states, in Principle VII, that a per-feature deliverable lives beside
  the specification it concerns, and names `test-plan.md` and `uat-report.md`.

## [1.20.0] - 2026-10-15

### Added
- **`speckit.spectra.deployment-strategy`** — the Deployment Strategist, in the Deployment & Operations
  phase. It reads the project and any local documents you reference, classifies what ships (service,
  static site, library, CLI or desktop tool, mobile app, or infrastructure), and writes one strategy to
  `<artifact-root>/DEPLOYMENT_STRATEGY.md` — by default `docs/DEPLOYMENT_STRATEGY.md` — covering six
  lenses: environments and promotion, pipeline and artifact traceability, release and versioning, data and
  schema change, rollback and recovery, and operability and configuration. Every claim is marked
  `verified`, `claimed`, `stated`, or `convention`; values only the client or ops owner can supply go to
  an open-questions section instead of being invented. Five questions — hosting, production approval, a
  pre-release environment, recovery targets, release cadence — are asked once per project and one at a
  time, each with a recommendation and its evidence. It drafts a constitution amendment carrying only
  durable invariants and ends with a ready-to-paste `/speckit-constitution` line; it never writes the
  constitution, edits nothing else, runs nothing, and makes no network request.
- **`deployment-strategy-template`**, registered and resolved through Spec Kit's template stack. Override
  at `.specify/templates/overrides/deployment-strategy-template.md`.

### Changed
- **`kb-vault` routes a supplied deployment strategy to the singleton.** Its reserved map gains
  `DEPLOYMENT_STRATEGY.md` beside the test strategy and domain analysis, so an ingested strategy joins the
  file the Deployment Strategist rewrites rather than landing in a category folder beside it.

### Governance
- Spectra's own constitution (1.10.0) names `<artifact-root>/DEPLOYMENT_STRATEGY.md` as the third
  standing-policy singleton, as Principle VII requires before a command may write one.

## [1.19.0] - 2026-10-15

### Changed
- **`domain-analyzer` writes its proposal to `<artifact-root>/DOMAIN_ANALYSIS.md`** — by default
  `docs/DOMAIN_ANALYSIS.md` — instead of `.specify/memory/domain-analysis.md`. An SME reviews, edits, and
  ticks that file before it reaches the constitution, so it is a deliverable and now sits with every
  other document a human reviews. It resolves the root the way every document agent does: the
  constitution's `Artifact root:` line first, then the publication check before defaulting into `docs/`,
  taking the non-publishing option when no choice can be obtained.
- **`domain-analyzer` ends with a ready-to-paste handoff.** Its report links the file it actually wrote
  and gives the exact `/speckit-constitution` prompt that adopts only the checked guardrails. It still
  never invokes the constitution command itself, and gives no prompt when nothing is left to adopt.
- **A re-run of `domain-analyzer` no longer re-offers what an SME already decided.** A candidate's ID is
  now frozen once written, so a guardrail the SME reworded keeps it, and regenerating its original
  wording matches instead of reappearing as new. A fresh candidate is also matched by intent, within
  its section, against every existing item — checked, unchecked, or edited — so an item left unticked
  stays rejected rather than coming back under a new ID.
- **Guardrails already in the constitution are marked `status: adopted`.** On a re-run, a checked item
  whose intent the constitution now asserts gets `adopted: <Principle>`, with its tick and wording left
  as they were, and the handoff contract excludes `adopted` items from the selected set. Running the
  `/speckit-constitution` prompt again therefore adopts only what is genuinely new. An adopted item is
  never reverted; if its principle later stops covering it, the drift is reported.
- **`test-strategy` writes `<artifact-root>/TEST_STRATEGY.md`** — by default `docs/TEST_STRATEGY.md` —
  instead of `<artifact-root>/test-strategy/TEST_STRATEGY.md`. A folder that can only ever hold one file
  added nothing. Its handoff now gives the same linked, ready-to-paste `/speckit-constitution` prompt.
- **`test-plan` and `kb-vault` follow the strategy to its new path.** `test-plan` looks for
  `TEST_STRATEGY.md` at the root first and falls back to the earlier location; `kb-vault`'s reserved map
  routes a supplied test strategy or domain analysis to the root-level singleton.

### Added
- **`domain-analysis-template`**, registered and resolved through Spec Kit's template stack like every
  other Spectra document. Override at `.specify/templates/overrides/domain-analysis-template.md`. The
  checkbox-per-candidate format and its metadata keys stay with the command, because
  `/speckit-constitution` reads them.

### Migration
- **Nothing is moved for you.** On the next run each command reads the file an earlier version wrote —
  `.specify/memory/domain-analysis.md` or `docs/test-strategy/TEST_STRATEGY.md` — so prior answers and
  every SME tick carry over into the new file. It reports the earlier file once and offers the
  `git mv` / `git rm` to run; it never moves, edits, or deletes it itself.

## [1.18.1] - 2026-09-20

### Changed
- **The packaged `TRADEMARK.md` no longer points at a closed issue tracker.** Its Questions section
  told a reader to open an issue on the repository. Issues are disabled there and the repository has a
  single owner and maintainer who accepts no outside contributions, so the pointer sent people at a
  404 and implied a channel that does not exist. It now states that plainly and leaves the terms above
  it as the complete statement of what the Apache-2.0 grant withholds.
- **A changelog reference to a deleted source document was rewritten.** The 1.18.0 entry cited the
  August requirements document behind `review-pr` by path; that document was removed from the
  repository, and the entry now cites `specs/008-review-pr/`, which carries the same record.

No command, template, or agent behaviour changed. The version moves because the packaged bytes did.

## [1.18.0] - 2026-09-18

### Changed
- **`speckit.spectra.review-pr` now proposes blockers and majors instead of pre-selecting nothing.** A
  reviewer reported that published reviews carried too much noise, and believed the command already
  proposed the narrow set and published it on a "yes". It did not. Step 8 read *"Nothing is
  pre-selected"*, `yes` was not in the grammar at all, and `blockers+major` existed only as one row in a
  ten-row table the reviewer had to know and type unprompted.

  A blank prompt is not a neutral choice. Facing sixteen findings and an unfamiliar syntax, the option
  needing least interpretation is `all` — and `all` is the outcome the command's own opening calls worse
  than no review, because *"the author learns to skim"*. The interaction was producing the exact failure
  the design was written to prevent.

  So Step 8 now renders a proposal: the blockers and majors it will publish, with severity, class and
  anchor; the findings it will not, **enumerated by number** and grouped by severity; the verdict that
  follows; and `all` offered plainly on its own line. `yes` accepts all of it and goes straight to the
  preview. The dropped findings are named rather than counted, because the proposal narrows what is
  *published* and must never narrow what is *shown* — a reviewer who cannot see the numbers cannot answer
  `1,4,11`.

  **`yes` carries the verdict, and that is safe by construction rather than by care.** The verdict is
  already derived mechanically — any blocker or major means request changes — so a proposal containing
  one can never *propose* approval. The collapsed answer therefore cannot reach the approve-over-blocker
  path; that path is entered only by a reviewer who types `approve`, and it keeps its typed confirmation
  in full. The argument is written into Step 9 beside the skip, so a later editor meets it before
  removing the collapse as unsafe.

  With no blockers or majors the default becomes publish-nothing, stated as such, with `approve` offered
  explicitly — approving a clean PR carrying six nits should not require inventing a syntax.

  **Silence still publishes nothing, and it is now said twice rather than once.** Two guarantees had been
  sharing one sentence: that an unanswered prompt posts nothing, and that no set is proposed. Only the
  second moved. The first is restated more explicitly than before — a reviewer who says nothing has not
  said `yes`, and an unanswered prompt is not a default accepted. **The preview gate is untouched**: the
  complete body and every inline comment, including every suggestion block, are still shown verbatim
  before anything is posted. Every existing selection form — `none`, `all`, ranges, severity groups,
  `except`, `<n>:major`, `<n>:body` — works unchanged, and any selection other than `yes` still goes to
  Step 9 for the verdict.

  **The published disclosure line changed with it.** It claimed *"every finding below was individually
  selected by the reviewer"*, which a one-word `yes` makes false — a reviewer accepts a set rather than
  picking its members one at a time. It now reads *"every finding below was shown to the reviewer and
  accepted before posting"*, which is true on every path, and the command says why so it does not drift
  back.

  The default threshold joins the severity rubric, the confidence cap, the anchor rule and the verdict
  derivation as command-owned and not template-overridable, for the same stated reason: a project that
  could lower it would break the guarantee that two reviews of the same diff agree.

  Nothing about what reaches the pull request when a finding is dropped has changed — dropped findings
  never appear there, in the body or on a line, exactly as before. The August source requirement's BR-18
  still read "nothing pre-selected"; it was a historical input, not a live requirement, and recorded
  what was asked for then rather than what ships now. `specs/008-review-pr/` carries the same record.

## [1.17.2] - 2026-09-12

### Fixed
- **The strategy document's front matter now parses.** A generated `TEST_STRATEGY.md` failed to render —
  *"Nested mappings are not allowed in compact mappings at line 10"* — and a reader that cannot parse
  the header shows an error instead of the document, so a correct strategy was lost to a stray
  character.

  Two violations, not one. `amendment_state` was emitted as a sentence — *"PARTIAL - drafted and
  APPROVED by the user in this session. Not written to the constitution: this command never writes that
  file."* — and the colon in the middle of it reads as a nested mapping. Four lines later
  `clarification_round` carried a sentence *and* an indented sequence beneath the same key, which is
  invalid no matter how the first one is quoted.

  The cause was not the fields; it was describing them in prose. Step 10 named the contents in
  sentences — "the coverage-of-analysis statement", "the amendment state", five questions with four
  fields each — showed no shape, and closed by asking for the header to be kept terse. That hint lost
  to the surrounding instruction to record everything, which is what hints do. `speckit.spectra.impact`
  has emitted front matter since it shipped without ever doing this, and the only structural difference
  is that it **shows** a literal block instead of describing one.

  So this one does too. Step 10 now carries a worked YAML example and four rules: it has to parse;
  every free-text value is quoted — all of them, not just the ones you spot a colon in; a key takes a
  scalar or a collection and never both; and anything that would run to a paragraph goes in the body.
  `amendment_state` becomes one word from a fixed set, because the proposed-amendment section already
  carries the state, the governing clause, the conflict, and the approval in full — a header repeating
  a paragraph is what broke the document. `disposition` is likewise enumerated.

  **The clarification answers stay in the front matter.** They are there because a project's template
  override may delete the body section that holds them, and the header is the only part of the document
  the command owns — so the fix reshapes the header rather than relocating the record, and the command
  now says outright not to resolve a future rendering problem by deleting the block.

  `speckit.spectra.test-plan` was checked and has no exposure: it emits a Markdown identifying block,
  not YAML. No other document command emits front matter at all.

## [1.17.1] - 2026-09-12

### Fixed
- **A session is non-interactive only when you say so.** `speckit.spectra.test-strategy` and
  `speckit.spectra.test-plan` both opened their non-interactive section by asking the agent to *detect*
  a session that cannot answer, from "piped input, no terminal, an automated runner". Those are process
  facts — `isatty()`, the state of a file descriptor, the identity of a parent process — and a command
  file is a prompt. The thing reading it has none of those to look at, so it guessed.

  The guess was not random, which is what made this worth a release of its own. Asked to decide whether
  anyone is going to answer, the tempting choice is the one that cannot leave you stuck waiting, and
  that choice is to assume nobody is there. The sentence biased toward exactly the outcome it should
  have made rarest.

  While the switch only suppressed the coverage-run confirmation and the amendment approval, a wrong
  guess was nearly invisible — both were already declinable and both had graceful defaults. 1.17.0 hung
  the entire clarification round on the same switch, and the failure stopped being invisible: a live
  interactive run, with a maintainer watching, announced itself non-interactive, skipped all six
  questions, recorded each as not asked, and then explained the omission in the document as though it
  were a considered judgement. A silent failure that argues for itself is the worst shape a defect can
  take.

  So the trigger is now a declaration rather than a deduction. A session is interactive unless
  `--non-interactive` is in the arguments, or the user or runner says in the session that no answer can
  be given. Those two are the complete set, the three unobservable criteria are gone rather than
  reworded, and both commands now carry the reason — so the next editor does not restore them for
  tidiness — along with the asymmetry that justifies the default. Ask in an empty room and you have
  wasted one question, which both commands already handle by taking the recommended answer and moving
  on, without classifying anything. Stay silent in a room with someone in it and you have thrown away
  the whole interaction.

  **Nothing about a declared non-interactive run changed.** `test-strategy` still asks nothing, runs no
  coverage tool, takes the non-publishing root, writes the document, and records the amendment as not
  asked — it still never infers approval from silence. `test-plan` still refuses to rewrite a plan that
  already exists and reports what it would have changed instead. The guarantee was always about what
  happens once the condition holds; only how the condition is recognised has moved.

## [1.17.0] - 2026-09-12

### Changed
- **`speckit.spectra.test-strategy` now asks before it writes.** Five judgment calls, one at a time,
  each carrying the answer the agent would have chosen and the evidence behind it: where the testing
  weight should sit, whether anything outside the repository depends on an interface here, which
  journeys justify an end-to-end test, what has broken that the tests did not catch, and what
  constraints the repository does not show. Then it writes the same single document to the same place.

  Three decisions a reader would otherwise find surprising:

  **It refuses to ask most of what you might expect.** Not whether the project is greenfield or
  brownfield, not what the stack is, not how many surfaces there are, not what the coverage figure is.
  Those are measured in Steps 1 to 3 and Step 8, and a question whose answer the agent is about to
  measure invites a wrong answer to outrank a right one — the document then rests on it. That rule was
  already settled for the mode when this agent shipped; 1.17.0 generalises it and writes the never-ask
  list into the command, where a well-meaning edit cannot quietly drop it. What remains is what no
  repository states: intent, priority, and the constraints an organisation imposes on a stack that
  could technically run anything.

  The fifth question is the one that earns the feature. The agent already refused to name a tool whose
  prerequisites a surface lacks. It had nothing to say about a tool the surface *can* run and the team
  may not adopt — no container runtime in CI, a freeze on new dependencies, no network in the test
  environment, a compliance rule. A strategy built on one of those is a document nobody can act on,
  which is exactly the plausible-but-useless output the agent exists to avoid.

  **Declining costs nothing, and that is load-bearing rather than polite.** Every question arrives with
  a recommendation already made, so "use your defaults" ends the round immediately and produces the
  document 1.16.0 would have produced. An unanswered question takes its recommendation and is recorded
  as not asked; a reply that is not an answer is answered and the same question asked again, rather
  than being read as a refusal. A new `--non-interactive` flag declares up front that no answer can be
  taken — matching `speckit.spectra.test-plan`, which already accepts one — and a piped or terminal-less
  run behaves identically without it. A non-interactive run and a fully-declined run produce the same
  document by construction, not by coincidence.

  **An answer can never move a number.** Recommendations have always carried either a citation or a
  `convention` marker. An answer is neither, and without somewhere honest to put it an answer either
  launders itself into a fake citation or is mislabelled a convention — at which point the rule that
  makes the whole document trustworthy quietly stops meaning anything. So there is now a third
  provenance, `stated`, naming the question it came from, and a new rule R7: answers shape judgment,
  never measurement. Ask for a 90% floor in a repository measuring 31% and the floor stays at 31%,
  because a floor that fails the next build gets deleted regardless of who asked for it. Where an
  answer contradicts the evidence, the change is made where it is legitimately yours to make and the
  disagreement is recorded in the document rather than argued in the session.

  Every question, its recommendation, the answer taken, and whether it was answered, defaulted, or
  never asked is recorded in the document's sources-and-coverage section — and again in its front
  matter, because a project override may reshape that section and the provenance record has to survive
  it. On a re-run the recorded answers pre-fill the round, so it confirms rather than interrogating a
  second time.

  The coverage-run confirmation moved into the round and is now asked first, before the five, because
  its answer produces the baseline and "where should the weight sit" is a different question at 31%
  than at 78%. That also collapses two separate interruptions into one. The document, its location, its
  ten sections, and the rule that this agent never writes your constitution are all unchanged.

## [1.16.0] - 2026-09-11

### Added
- **`speckit.spectra.kb-vault` — the knowledge your team has, in the repository where agents can read it.**
  Attach the documents — a PDF of architecture decisions inherited from a previous team, a Word file
  describing the engineering workflow, a deck of UX/UI standards, a diagram exported as an image — or
  just describe what you know. It absorbs all of it, works out what kind of document each source is,
  learns how your project already keeps documentation, and shows you a table of exactly what it intends
  to write and where. Then it stops and waits. Only after you approve does anything land, as Markdown,
  under your artifact root.

  Three decisions a reader would otherwise find surprising:

  **It shows a plan and stops, which no other document agent does.** Every other Spectra command writes
  as its final act and you see the result. This one is aimed at repositories that already have
  documentation, where an unwanted *update* is not trivially undone by someone who did not notice it
  happened — so the plan table is the safety mechanism, and a comment on it is not approval of it. Any
  change re-presents the whole table. An ambiguous answer writes nothing.

  **It updates rather than duplicates, even outside the artifact root.** Supply a revised standards
  document and it finds the one you already have — matching on subject and category, never on title
  similarity — and edits it in place, at its existing path, keeping its name and the hand-written
  sections your source never mentions. That is a deliberate departure from the usual "one root, one
  folder" rule: on any project whose documentation predates Spectra, writing the update into the root
  instead would leave you with two documents disagreeing with each other and no rule for which is
  current. New files stay bounded to the root; only updates go where the document already lives.

  **It never invents, and it never mines your codebase.** Every substantive sentence traces to
  something you supplied. A template section with no source says so instead of being filled. A file it
  cannot read is named and its content requested — never guessed at from the filename. A diagram is
  transcribed only as far as it is legible, and where the structure will not carry, it says that rather
  than implying a picture is present. And "document the architecture" with nothing attached gets you a
  request for material, not documentation reverse-engineered from source code.

  Where a supplied document is a kind Spectra already produces — an ADR, a BRD, an impact analysis, a
  test strategy, a defect RCA — it adopts that agent's folder, numbering and template, so it joins the
  existing set rather than starting a second one beside it. Everything else takes its own category
  folder, with an index maintained beside it. Six sections, overridable at
  `.specify/templates/overrides/kb-document-template.md`, or per category at
  `.specify/templates/overrides/<category>-template.md`.

  It commits nothing. When the files are written it tells you they are uncommitted and hands the review
  back to you.

- `kb-document-template` — the default shape for an ingested knowledge document: purpose and scope with
  real exclusions, context, the substance in whatever structure the source actually has, the rules and
  decisions pulled out so they can be cited, the open questions and gaps, and provenance naming the
  sources it came from.

## [1.15.0] - 2026-09-11

### Added
- **`speckit.spectra.defect-rca` — the root cause, not the first plausible code path.**
  Hand it a defect — a JIRA ticket reference, a GitHub issue URL, or just a description of what went
  wrong — and it reads the project before it asks you anything: the constitution, the implicated code,
  the commits that touched it, the configuration, the tests. It builds a MECE hypothesis tree, tests
  what the repository can settle, asks at most five questions per round about the runtime facts nobody
  can grep for, and writes one advisory analysis to `docs/defect-rca/NNN-<slug>.md` — or wherever the
  project's declared artifact root puts it — with the root cause stated first, the evidence that
  settled it, the impact, and corrective and preventive actions carrying owners and verification
  criteria.

  It fixes nothing, writes no test, and updates no ticket. The conclusions are yours; it is a coach and
  a structuring aid.

  Four decisions a reader would otherwise find surprising:

  **It attempts and degrades on `gh` rather than gating on it.** `create-pr` and `review-pr` refuse to
  run without the GitHub CLI, because their whole purpose is unreachable without it. A GitHub issue is
  one of three channels here, so a missing or unauthenticated `gh` is named with its specific remedy —
  install, versus `gh auth login` — and the run continues from a pasted description. What it never does
  is degrade into asking for a credential: a prompt that requests an API token is a phishing surface,
  and this one ships in a package.

  **It searches your prior analyses at intake, not at synthesis.** A recurrence surfaced after the
  document is written is a recurrence surfaced too late to change the analysis. Matches are made on
  implicated code, symptom, or root cause — never on title similarity — and the firing axis and the
  concrete overlap are always disclosed, so a spurious match costs one sentence to dismiss. Each of the
  earlier analysis's preventive actions gets a verdict of apparently completed, apparently not
  completed, or undeterminable, and **the first two require a citation**. `undeterminable` is the
  default, because an uncited "completed" against an action nobody finished makes a recurrence read as
  a fresh defect.

  **It refuses to call a layer-two finding a root cause.** Reading the code produces a specific failure
  mode a human interviewer does not have: the plausible path you find is genuinely there and genuinely
  related, which makes stopping feel like finishing. So every probe names its layer on the symptom →
  immediate cause → contributing factors → process gap → systemic cause ladder, and where the deepest
  validated finding is still an immediate technical cause, the run says so and names what would go
  deeper rather than promoting it under a "Root Cause" heading.

  **It writes two files and reads everything else.** The analysis and a rebuilt folder index, both under
  one directory, both as the run's final act — so an interrupted run consumes no sequence number and
  leaves nothing behind. The hypothesis tree, the issue trees, and the session notes are rendered in
  the conversation and never written to disk.

  Registered template: `defect-rca-template`. Override it for your whole team at
  `.specify/templates/overrides/defect-rca-template.md`.

## [1.14.0] - 2026-09-11

### Added
- **`speckit.spectra.test-plan` — the tests, agreed before anyone writes them.**
  Run it after `speckit.specify` and before the planning command, on one feature at a time. Hand it the
  path to a `spec.md` and it reads that specification, the constitution, the project's test strategy, the
  existing suite, and the source the feature touches, then writes one `test-plan.md` **beside the
  specification**: scope, risks, traceable test conditions, environment and data, and exit criteria. The
  document is circulated and approved; the planning command then designs around it.

  It is for teams that want the test set settled before the implementation is designed. It produces no
  tasks, writes no test code, and tracks nothing.

  What separates it from a template fill-in is the traceability, enforced in both directions. **Every
  acceptance criterion in the specification reaches at least one test condition, or is reported as
  uncovered with a reason** — never absent from both. **Every condition names what it verifies**, using
  the specification's own identifier (`FR-014`, `SC-003`, or the composed `US2-AC1` for an acceptance
  scenario), so a reviewer can check coverage in either direction without reading the code. The run states
  the count: criteria covered out of criteria found.

  Four decisions a reader would otherwise find surprising:

  **The specification path is required, and it is never inferred.** Not from the current branch, not from
  `.specify/feature.json`, not from modification times, not by scanning `specs/` — and it does not offer a
  picker either. With no argument it asks and stops, having read nothing. This is deliberately less
  helpful than the rest of the workflow, because the output is a document that gets circulated and signed:
  a plan generated against the wrong specification reads as authoritative and is undetectably wrong to
  whoever approves it. A picker is the same failure with extra steps.

  **The plan is written beside the specification, not under the artifact root.** No sequence number, no
  artifact subfolder. A test plan is *about one feature* and is consumed by the planning command, so its
  identity is the feature's directory — exactly as the specification and plan next to it carry no number,
  because the directory already supplies one. This is a documented reading of the convention's carve-out
  for Spec Kit's own locations, argued in `specs/021-test-plan-agent/plan.md`.

  **It carries no checkbox, in any section — exit criteria included.** It is approved, not tracked. An
  approved, circulated document with live checkboxes creates a second apparent source of truth about
  progress, and it will disagree with `tasks.md`. A checkbox reintroduced by a template override is
  rendered as a plain statement instead: the team's section is kept, only the construct goes.

  **The planning handoff is printed text, not a hook.** The run ends with a ready-to-copy invocation
  naming the written path. No `before_plan` hook is registered and no core command is edited, so the
  planning command works exactly as it does today for anyone who never installs this agent — which is
  what makes it genuinely optional.

  It inherits rather than invents. Level names come from `docs/test-strategy/TEST_STRATEGY.md` **verbatim**
  where one exists, so the two documents read against each other; otherwise from the constitution, else
  from convention — with `manual` always available, because a plan must be able to place a condition no
  automated lens will ever cover. A declared coverage floor is carried into the exit criteria and
  attributed, never adjusted. No level or tool is assigned that the project's manifests cannot support, so
  a command-line tool never gets a browser driver. Existing coverage is established by **reading test
  source, never running it**: a coverage claim cites the test file, and an absence claim cites the search.
  Where a requirement is too ambiguous to test, it says so and writes no condition — a fabricated
  condition would launder a guess into something a stakeholder approves.

  Risk ratings are derived from stated triggers rather than judged, capped at two to five rows, with
  `accept` a first-class response. Condition priority is inherited from the specification's own story
  priorities, with prohibitions and data-integrity properties promoted to P1 regardless. Re-running asks
  before rewriting, states what would change, and carries forward every explicitly-not-covered decision.
  One file per run. Nothing executed. No network request.

  Shaped by the new registered `test-plan-template`, overridable at
  `.specify/templates/overrides/test-plan-template.md`.

## [1.13.0] - 2026-09-10

### Added
- **`speckit.spectra.test-strategy` — the testing strategy a project inherits, decided once at the start.**
  Run it in the foundation phase, alongside the constitution, before there are features to plan. It reads
  the project, decides for itself whether this is a greenfield or a brownfield codebase, and writes one
  strategy covering unit, integration, API contract, and end-to-end testing plus a coverage floor — to
  `docs/test-strategy/TEST_STRATEGY.md`, or the project's declared artifact root.

  What separates it from a template fill-in is what it refuses to say. **Every recommendation either cites
  a path in the project or is explicitly marked as a convention with no project evidence** — never neither.
  **No tool is named that the stack cannot run**, ranked across three tiers: already in a manifest,
  ecosystem-standard for a stack the project demonstrably uses, or unverified and flagged as offered from
  frozen knowledge. That is why the end-to-end lens resolves to browser, HTTP, CLI, or *none* rather than
  defaulting to a browser driver — a published library gets `none`, which is the honest answer.
  **A claim that something is missing cites what was searched and where**, and the run always states how
  much of the repository it actually read.

  Three decisions a reader would otherwise find surprising:

  **The strategy is a singleton, rewritten in place.** Every other Spectra document agent numbers its
  output because it produces a series; this one produces a standing policy with exactly one current
  answer, like the constitution. The path is fixed so anything can link to it, and Git carries the
  history. This is a deliberate, documented departure from the artifact-numbering convention, argued in
  `specs/020-test-strategy-agent/plan.md`.

  **It never writes the constitution.** Not on approval, not on a re-run, not when the user insists. It
  detects whether the strategy is already embedded — quoting the governing clause where it is — drafts the
  exact amendment in the constitution's voice, takes the approval, records the text in the strategy
  document, and hands off to `speckit.constitution`, which owns the sync impact report, the bump-type
  judgement, and dependent-artifact propagation. One owner for every constitution edit.

  **It runs nothing unless you say so.** Coverage figures carry their provenance — `measured` only if it
  ran the tool this session after asking, `reported` (with the report's date) if it read a committed file,
  `unavailable` if there is nothing to read. That distinction is load-bearing, because in a brownfield
  project **the proposed floor is never above the baseline**: a floor that fails the next build gets
  deleted, and a deleted floor is worse than none. Where the floor is below the target, the ratchet is
  expressed as triggers rather than dates.

  It recommends configuration and never applies it: the exact CI or coverage change is stated for the team
  to make. Ten sections, overridable at `.specify/templates/overrides/test-strategy-template.md`.

## [1.12.1] - 2026-09-09

### Changed
- **The extension now points at `github.com/telus-digital/spectra`.** The repository moved from the
  `xavient` organisation to `telus-digital`, and the manifest's `repository` and `homepage` URLs moved
  with it — as did the links in the packaged `NOTICE` and `TRADEMARK.md`, the two files a consumer reads
  to find out who owns the work and where to raise an issue. No command changed: the roster, the
  templates, and the behaviour of every agent are identical to 1.12.0.

  The version moves because the packaged bytes did. GitHub keeps the old paths reachable with a rename
  redirect, so nothing breaks today — but that redirect holds only while the `xavient` organisation name
  stays unclaimed, and an install path resolving through a name anyone can register is not something to
  leave sitting in a shipped package.

## [1.12.0] - 2026-09-03

### Added
- **`speckit.spectra.impact` — a feature impact analysis a BA can take to a stakeholder gate.** Give it one
  paragraph describing what should be true after a feature ships, and it scans the project, works out what
  the change would touch, asks at most five clarifying questions about the things code cannot answer, and
  writes a numbered Markdown document under `docs/impact-analysis/` — or the project's declared artifact
  root. It runs *before* `specify`, because the point is to inform the go / no-go decision that authorizes
  development spend.

  What makes the output usable at a gate is what it refuses to do. **Every finding carries a
  `path/to/file.ext:142` citation and one of three confidence levels**, with the level fixed by the *kind* of
  evidence rather than by how convincing it felt — a document with no code citation never reaches
  `confirmed`. **The impact rating is a lookup, not a judgement**, derived from a defined trigger set and
  reported with the trigger that fired. **Absence of evidence is never reported as absence of impact**: "no
  consumers found in what was scanned" is permitted, "no downstream impact" is not. **Coverage is stated per
  system** — files read of files present, and by what method — alongside the terms that were searched for and
  produced nothing, so a reviewer can tell "I checked and found nothing" from "I did not check".

  Five bounded phases do the work — a structural map, term expansion across naming conventions, a
  role-weighted seed search, two-hop graph expansion, and two sweeps for the coupling static reading misses:
  dynamic dispatch, string-keyed registries, config-driven behaviour, and a raw-string sweep of every
  contract identifier (table and column names, endpoints, events, topics, config keys, flags, env vars)
  across the whole project. Each phase has a disclosed cap, overridable per run, and reaching one is
  reported rather than absorbed.

- **`impact-analysis-template`, the fifth registered template.** The document's ten sections resolve through
  Spec Kit's four-layer stack, so a team reshapes every future analysis by committing
  `.specify/templates/overrides/impact-analysis-template.md` — including deleting a section, which the
  command notes rather than reinstating. The trustworthiness rules stay with the command: an override can
  drop *Sources consulted*, and coverage is still reported in the session.

### Notes
Three decisions in this command are deliberate and worth stating, because each one is a capability someone
will look for and not find.

- **No network access, and no external repository fetching at all.** The command accepts no repository URL,
  credential, or token, and never clones or downloads anything — not even a public repo with `gh` already
  authenticated. Where a system spans more than one repository, the other systems are declared as free text,
  as a document, or as a **path to a local copy that is read in place** and never modified or copied. A
  system with no local checkout is *described* rather than searched, and still produces a targeted handoff
  item naming the owning team and the contract to confirm. Spectra opens no channel your agent does not
  already use, and this command holds that line rather than becoming the first exception.

- **No link to specifications, in either direction.** An impact analysis and a spec are independent
  processes. The document carries no `spec_refs` field, nothing under `specs/` is written or depended on, and
  `speckit.specify` is unchanged and unaware. Existing specs *are* read — as evidence, and they make the scan
  cheaper and better-oriented — but reading one creates no relationship to it, and a spec that disagrees with
  the code becomes a finding rather than a resolution.

- **The approval gate is manual.** Every run writes `status: draft`. The BA takes the draft to stakeholders
  and records the outcome in the front matter themselves; the command never sets, prompts for, or infers any
  other status. Because a human owns that field, the folder index is **rebuilt from the documents on every
  run** rather than appended to, so an approval recorded by hand reaches the index without the command
  touching a document to get it there.

Re-runs never overwrite. Every run allocates the next number — one greater than the highest present, not a
count of the files — and identical input twice produces two reports, each carrying its own timestamp and its
own verbatim record of what it was asked. An interrupted run leaves the folder untouched and consumes no
number, because the document and the index are written once, as the run's final act.

## [1.11.1] - 2026-08-31

### Added
- **`TRADEMARK.md` now ships inside the extension.** Apache-2.0 §6 withholds trademark rights, but
  until now the extension said nothing about which marks that covers. A consumer with only the
  installed package in front of them could see a permissive licence and a TELUS Digital logo in the
  same tree and reasonably conclude the logo came with the grant. `TRADEMARK.md` states what is
  excluded — the TELUS marks, "Spectra" as a project identifier, and the logo — and that a fork must
  rebrand. It sits beside `LICENSE` and `NOTICE` rather than only at the repository root, so the
  carve-out travels into every consumer's `.specify/` directory instead of dangling as a reference to
  a file they do not have.

### Changed
- **`NOTICE` carries the trademark carve-out, third-party attributions, and a regulatory
  disclaimer.** The attribution mechanics under §4(b) and §4(d) are unchanged; three sections are
  added on top. The third-party section names GitHub Spec Kit and reproduces the MIT permission
  notice verbatim, which the repository owed for the copies of Spec Kit's own `git` and
  `agent-context` extensions it carries; it also disclaims affiliation with AWS over the AI-DLC
  references, and with every standards body, regulator, and certification authority the agents name.
  The disclaimer says plainly what the compliance agents are: readiness-support tooling that produces
  drafts for human review, never certification or audit. `NOTICE` is the one file a downstream
  redistributor is required to carry forward, which makes it the right place for all of this.
- **The extension README's licence section states obligations rather than permissions**, and points
  at the shipped `TRADEMARK.md` and the disclaimer.

## [1.11.0] - 2026-08-26

### Added
- **`speckit.spectra.flaky-test-detector` — find the tests that pass and fail on the same code, then fix
  the ones you approve.** The conventional way to find a flaky test is to instrument CI, collect hundreds
  of runs, and compute a score: pipeline changes, a results store, and weeks of waiting before the first
  answer. This agent needs none of it. The causes are visible in the source — an unconditional sleep
  before an assertion, an un-awaited async call, state one test leaves for another, a live network call,
  an unseeded random value, an assertion against the real clock — so it reads the test suite and names
  them, on the day you install it.

  **It never runs anything.** Not the suite, not a build, not an install, and not to verify a fix it just
  applied. That last exclusion is deliberate: an agent that can run the tests it edited is an agent that
  can iterate until green, and iterating until green is how tests get weakened. Verification stays with
  you and your CI.

  **A fix removes the cause.** Deleting an assertion, loosening one until it always passes, skipping the
  test, marking it expected-to-fail, adding a retry wrapper, or lengthening a sleep are all forbidden as
  remedies. Edits are confined to test and test-support files; where the real fix belongs in application
  code, the item is left open with a note saying what would need to change and where.

  **Two gates, and pruning in between.** The run reports a ranked table — test, file, confidence, and a
  concrete fix — and stops. On your go-ahead it writes `.specify/memory/flaky-test-analysis.md`: a run
  summary, one `[ ]` row per candidate, the evidence behind each, and what it could not examine. You
  delete the rows you disagree with. On a second go-ahead it works what is left, one item at a time,
  ticking each `[x]` on disk as it lands — so an interrupted session leaves a file that is exactly true.
  Nothing is ever committed.

  **The list outlives the session.** Every run reads that file first and branches on its state: unfinished
  work resumes without re-analysing and without discarding your pruning; a completed list asks before it
  is replaced; a file it cannot parse is never overwritten silently. There is exactly one analysis file at
  any time. Before a run scoped to one suite replaces a broader plan, it names the pending items that
  would be dropped and waits.

  Confidence is High, Medium, or Low, and it rates the strength of the evidence rather than a failure
  rate — with no run history there is no denominator, so the agent emits no percentage or score. Your
  project's own constitution binds the choice of fix: where a guardrail rules out the only remedy, the
  item is left open with that rule named.

## [1.10.0] - 2026-08-22

### Changed
- **`speckit.spectra.review-pr` no longer looks for a spec in `.specify/feature.json`.** Spec Kit now gitignores
  that file — its own CLI writes the rule, describing it as "per-checkout state rather than something to share" —
  so the second tier of the spec-discovery chain read a path that, at a pull request's head revision, is either
  missing or stale. Missing was the common case and cost nothing but a wasted call. Stale was the dangerous one: a
  project that committed the file before Spec Kit began ignoring it still carries whatever feature its last
  committer happened to be on, so the review would check the diff against **someone else's spec** and report full
  traceability while doing it. That is the exact failure the chain's ban on branch-name guessing exists to prevent.

  The tier is now **a spec you name**. When the diff carries no spec, the command asks for one and reads the path
  at the pinned head revision, falling through to the standalone review if it does not resolve there. The addendum
  case — the spec merged in an earlier pull request — stays covered, on evidence a human vouched for rather than on
  a machine-local pointer. Both forbidden guesses are now named in the command, with the reason recorded, so
  neither comes back by accident.

  **The run still asks at most one question.** When neither a spec nor an issue was found, the existing single
  context question asks for both together; `--issue` answers only its own half, so a run with no spec in the diff
  still asks for the spec. Tier 1 is untouched: a PR that ships its spec behaves exactly as in 1.9.1, and a PR with
  no spec anywhere is still reviewed standalone — traceability reported as not run, guardrails at full strength,
  intent findings capped at Question.

## [1.9.1] - 2026-08-21

### Fixed
- **An issue passed to `speckit.spectra.create-pr` now always reaches the pull request.** The rendering was
  already right — `Closes #42` when the base is the repository's default branch, a plain `#42` reference
  elsewhere, since GitHub ignores closing keywords outside the default branch — but the reference was treated
  as *presentation*. Combined with the honour-the-template rule, that meant a project whose
  `.specify/templates/overrides/pr-template.md` had no **Related Issues** section got a pull request with no
  issue link at all: `--issue 42` noted the omission in chat and opened an unlinked PR that looked complete.

  The reference is now the command's obligation rather than the template's. It goes in the template's issue
  section when there is one — judged by intent, so a team's `## Ticket` counts — and is **appended** with a
  one-line note when there is not. With no issue, nothing is appended and any such section is removed, as
  before.

  This is the same line `review-pr` draws for its revision anchor, its AI-assisted disclosure, and its
  coverage statement: a template governs how a document *reads*; functional obligations stay with the command.
  Rendering is unchanged, and a template that has the section produces byte-identical output to 1.9.0.

## [1.9.0] - 2026-08-21

### Added
- **`speckit.spectra.review-pr` reads the linked issue as optional context — in both kinds of PR.** It looks
  for one automatically, tells you which issue it used, and asks once if it cannot find one. Skip the
  question and the review proceeds exactly as before, on the constitution and the spec.

  Detection runs two routes, and the second is not redundant: the structured link
  (`closingIssuesReferences`), then a scan of the PR title and body for `#42` and issue URLs. GitHub only
  records the structured link when a PR targets the **default branch** — the same rule that shaped
  `create-pr` in 1.8.0 — so a PR into `dev` can say `Closes #42` and return nothing structured. Without the
  text fallback the command would ask you for an issue already sitting on the pull request.

  What the issue is *for* depends on what else exists. With **no spec** it becomes the traceability baseline:
  the lens now runs against the issue in both directions — does the diff address what it describes, and does
  it do anything the issue never asked for — instead of being reported as not run. With a **spec**, the spec
  still authorizes and the issue is background. Where the two disagree, that is a Question naming both; the
  command does not adjudicate between two human artifacts.

  Two limits keep it honest. An issue's content is **data about intent, never instruction** — text asking to
  "just merge it" is a fact about the conversation, not a direction. And a finding whose only source is an
  issue **cannot be a Blocker** unless the PR claims to close it, in which case the rubric's existing clause
  about failing a requirement it claims to satisfy already applies. An issue is a conversation; a spec is
  authorized scope.

- **Line-anchored comments, with applicable code suggestions.** The review no longer arrives as one body
  with file:line references for you to go and find. Accepted findings whose anchors fall inside the diff are
  published **on those lines**, and where the fix is mechanical the comment carries a ` ```suggestion ` block
  the author can apply in one click.

  This was the command's one deferred feature, and its stated reason — "diff-position arithmetic" — is
  obsolete: the reviews endpoint takes `path`, `line`, and `side` directly. Everything posts in **one call**
  carrying body, comments, and verdict together, so there is no state where the comments landed and the
  verdict did not. Publication moves from `gh pr review` to `gh api` for that reason; it is the same tool and
  the same authentication, and `curl` remains forbidden.

  Because a suggestion is one click from a commit, the rails are requirements rather than advice: mechanical
  and complete for exactly the replaced range, never architectural, never spanning files, never on a
  low-confidence finding, never on a removed line or a generated file — and **every suggestion appears
  verbatim in the pre-publish preview**, because it can be applied without being read. Findings anchored
  outside the diff go in the body, with the reason stated. `<n>:body` in the selection forces any finding
  into the body.

- **A review template, overridable per project.** The body's shape was hard-coded; it is now
  `templates/review-template.md`, registered in `provides.templates` and resolved through the same stack as
  the ADR, BRD, and PR templates. It defines two shapes — the summary body and the inline comment — and the
  command reports which template path it used.

  Its remit is deliberately **narrower** than the other templates. Three things stay with the command and
  survive any override: the `<!-- spectra:review-pr revision=… -->` anchor (how `--since` and self-review
  detection find previous reviews), the AI-assisted disclosure line, and the **Coverage and limits** section
  that stops a review implying assurance it did not earn. Judgment is not overridable either — the severity
  rubric and its floors, the confidence cap, the anchor rule, the selection grammar, and the verdict
  derivation stay in the command, because two reviews of the same diff have to agree.

  The shipped default keeps today's sections and adds a **Summary**, with `- [ ]` task items on Blockers and
  Majors only. Ticking a Question means nothing, so Minor, Nits, and Questions stay plain bullets.

### Changed
- **Coverage now says how much of the constitution applied**, not merely that the guardrail lens ran. A
  review reporting "guardrails: run" against three vague principles looks thorough and is not. It states how
  many principles were read and how many bore on this diff, says so plainly when none did, and names the
  domain-analyzer and constitution commands as the way to close that gap. An absent constitution is stated
  rather than implied.
- Coverage also records **which context authorized the review** — spec and discovery tier, issue with number,
  title and state, constitution, or the absence of each — and **what could not be placed inline**.
- The summary gained an **Issue status** line: the issue, its state, and how it was obtained.

## [1.8.0] - 2026-08-21

### Added
- **`speckit.spectra.create-pr` takes an optional `--issue`.** Pass a number or a URL (`--issue 42`,
  `--issue https://github.com/owner/repo/issues/42`) and the PR links to it. Omit it and the command asks once;
  skip the question and the PR is opened with no issue section at all. A reference that `gh issue view` cannot
  resolve is reported and dropped rather than written into the body broken.

  **The link is written differently depending on the base branch, and that is not cosmetic.** GitHub interprets
  closing keywords *only* when a PR targets the repository's default branch — on any other base the keywords are
  ignored, no link is created, and merging closes nothing. So a `Closes #42` on a PR into `dev` would look
  correct and do nothing. The command writes a closing keyword only when the base is the default branch;
  otherwise it writes a plain `#42` reference, which still records a cross-reference on the issue, and tells you
  auto-close will not happen on this merge. An issue in another repository is referenced by full URL, never with
  a keyword.

- **The PR body now comes from an overridable template.** `templates/pr-template.md` ships with the extension,
  is registered in `provides.templates`, and resolves through the same stack as the ADR and BRD templates:
  project override → presets → extension → core → an inline skeleton. Drop
  `.specify/templates/overrides/pr-template.md` into your project and every PR follows your structure —
  committed, team-wide, and surviving extension updates.

  Sections: Summary, Related Issues, Type of Change, Changes, How to Test, Screenshots / Evidence, Breaking
  Changes, Notes for Reviewers. **Deliberately no self-certification checklist** — an agent cannot honestly tick
  "I have self-reviewed the full diff". If your override reintroduces one, the command leaves those boxes
  unchecked and says it left them for you.

- **One final confirmation before anything is created.** The command summarizes source → base and where the base
  came from, the linked issue or nothing, draft or ready, the resolved template path, and anything it has
  already done — then asks once. Confirmations that used to be scattered now happen in one place.

### Changed
- **Uncommitted work is offered a commit instead of a warning.** Previously the command surfaced a dirty tree,
  warned that the PR would exclude it, and explicitly would not commit. It now lists the files and asks *"there
  are uncommitted changes, should I proceed with committing and pushing first?"* — and on a yes behaves like any
  ordinary commit-and-push request. Rails: the file list is shown before staging, credential-shaped names
  (`.env`, `*.pem`, `id_rsa`, `credentials*`) are called out for a specific go-ahead, nothing is blind-`git
  add -A`'d beyond what you saw, and `--no-verify` is never used — a hook that rejects the commit stops the run
  with the hook's own message. Answer no and the PR is opened from committed work with the exclusion stated
  plainly.

  This widens the command's write scope, which is worth saying out loud: it may now create a commit on your
  behalf, with your explicit consent, in addition to pushing and opening the PR. It still never edits source,
  the spec, the plan, the tasks, or the constitution.

- **The base branch: documented intent wins, and a guess is confirmed rather than assumed.** A promotion flow in
  the constitution or `.specify/extensions/git/git-config.yml` is used and cited, as before. With nothing
  documented, the command proposes a base — the branch this one appears to have been cut from, else the default
  branch — and asks at the final gate: *"This PR will be created to merge into `main`. Is that correct?"* You can
  redirect it in the same breath, and the corrected base is re-checked on the remote before use.

  The reason it asks rather than decides: **Git records no parent branch.** `@{upstream}` is the tracking branch,
  and `git merge-base --fork-point` reads the reflog, so it yields nothing in a fresh clone or CI checkout and
  nothing useful when two candidates share a commit.

- **It works from any branch now.** The one-branch-per-spec refusal is gone: a `fix/…` or chore branch can open a
  PR. Only two refusals remain — detached HEAD, and a branch that is already the resolved base. A spec branch is
  still better served: it contributes `spec.md`, `plan.md`, and `tasks.md` to the body, where other branches
  contribute their commits. Either way the **Changes** section comes from the real diff
  (`git diff --name-status <base>...HEAD`), not from a restatement of the plan.

- Constitution **1.7.1** clarifies Principle VIII: a deliverable is the document, not the destination, so a PR
  body a command emits is shaped by a template exactly as a file written to disk is. Only Principle VII's
  *location* rules are limited to files.

Every earlier guarantee is intact: the hard `gh` gate before anything else, GitHub-only scope, the duplicate-PR
check, `--head` always explicit, `--body-file -` for the body, and post-gate degradation that states exactly what
was mutated.

## [1.7.0] - 2026-08-21

### Added
- **Both document agents are now driven by an overridable template.** `speckit.spectra.adr` used to carry its
  structure as a literal block inside the command file — there was no file to change. It now ships as
  `templates/adr-template.md`, alongside the BRD template, and both are declared in `extension.yml` under
  `provides.templates`.

- **`.specify/templates/overrides/<name>.md` is the supported way to customize them.** Drop
  `.specify/templates/overrides/adr-template.md` (or `brd-template.md`) into your project, edit it, commit it —
  every document produced from then on follows your structure, on every teammate's machine. Add the sections
  your governance needs, or delete ones you don't want.

  Both commands now resolve their template through Spec Kit's stack, first usable layer wins: project override
  → installed presets → this extension → core `.specify/templates/` → the command's inline skeleton as a last
  resort. A layer that exists but is empty or unreadable is reported and skipped rather than being fatal.

  **This is the part that was broken before.** `brd` read the extension's copy at a hard-coded path, so an
  override was silently ignored, which left editing the installed copy as the only lever — and that edit does
  not survive: extension files are replaced wholesale when the extension updates. Because the path is tracked
  by Git, the edit looks durable and then reverts later inside an unrelated diff. An override lives outside the
  extension tree and survives.

- **Each command reports which template it used**, by path. An override that silently failed to apply
  otherwise looks exactly like one that worked, and the first clue would be a wrongly-shaped document.

### Changed
- **A resolved template is honoured, not repaired.** If your override renames, renumbers, drops, or adds
  sections, the command follows *your* structure and mentions once what it left out, instead of quietly
  reinstating it. Where your template adds sections, they are filled from the same gathered context; where
  there is genuinely nothing to say, the command says so rather than inventing content.

- **The ADR's section list is unchanged**: Context, Decision, Consequences, with the same `Date` and `Status`
  header. With no override in place, output is structurally identical to 1.6.0. Enriching the default was
  deliberately left out of this release — now that every project can add sections itself, changing the shipped
  default would have altered everyone's output while claiming to be additive.

- Constitution **Principle VIII — Documents Are Shaped by Overridable Templates** (constitution 1.7.0) records
  the rule so future document agents inherit it: the structure comes from a registered template resolved
  through the stack, with an inline fallback and never a hard-coded path; the resolved template is honoured as
  authored; the command names the template it used. Resolution stays prompt-expressed, because calling Spec
  Kit's Bash `resolve_template()` would break agent-agnosticism and shipping a resolver of our own would break
  the Markdown-only guarantee — the package still contains no scripts, no binaries, and no hooks.

## [1.6.0] - 2026-08-21

### Changed
- **ADRs and BRDs now go to one place: `docs/adr/` and `docs/brd/`.** `speckit.spectra.adr` used to write
  `Docs/ADR/ADR-NNN-*.md` and `speckit.spectra.brd` used to write `/brds/NNN-*.md` — two different parent
  folders, two different capitalizations, and one path that named the filesystem root rather than the
  project. Both now write under a single root, project-relative and lowercase, one subfolder per artifact
  type. Filenames are unchanged: `docs/adr/ADR-NNN-<title>.md` and `docs/brd/NNN-<title>.md`. The root
  itself is a project setting — see **Added** below.

  The lowercasing is a fix, not a preference. `Docs/ADR/` is a distinct directory on Linux but silently
  aliases into an existing `docs/` folder on a case-insensitive macOS filesystem, so the same command
  produced different layouts on different machines.

- **Existing projects keep their numbering, and their old folder.** Both commands still read the earlier
  locations — `Docs/ADR/` (matched case-insensitively), `brds/`, and `docs/<artifact>/` when a project
  declares a different root — for context and for the next number, so the sequence after this update
  continues from the highest artifact found across old and new instead of restarting at `001`. Those folders
  are read-only to the agent: it reports them once, offers a `git mv` you can run, and moves nothing itself.
  If a new ADR supersedes one that still lives in an earlier folder, the supersession is recorded in the new
  ADR and reported to you rather than written into the old file.

- **Every write scope is unchanged in size.** `brd` still writes exactly one file; `adr` still writes one
  ADR plus, only with your agreement, the superseded-status line and a constitution edit.

### Added
- **A project can move the artifact root with one line.** `docs/` is the default, not a hard-coded path.
  Put this in `.specify/memory/constitution.md` and every Spectra document agent — these two and every one
  we ship later — writes there instead:

  ```text
  Artifact root: documents/
  ```

  The commands offer that line but never write it themselves: producing a document is not a licence to edit
  governance.

- **A publication check before defaulting into `docs/`.** `docs/` is GitHub Pages' only non-root branch
  source and the default source directory for MkDocs and Docusaurus, so on some projects writing there
  publishes the document or breaks a docs build. Both commands now look for that signal — `mkdocs.yml`,
  `docusaurus.config.*`, `docs/_config.yml`, `docs/.nojekyll`, `docs/index.html`, `docs/conf.py`, or a Pages
  configuration pointing at `docs` — and when they find one with no declared root, they say so before
  writing, recommend `documents/`, and ask. Unanswered, they take the non-publishing option: a misplaced
  private file is one `git mv` away, while a BRD served on the public web cannot be recalled from caches or
  forks. The question does not count against either command's five-question limit, because it is about
  where to write rather than what to record.

- **Constitution Principle VII — Document Artifacts Live Under One Declared Root** (constitution 1.6.0).
  Every command producing a durable Markdown deliverable writes it to `<artifact-root>/<artifact>/` with a
  lowercase kebab-case slug, one artifact type per folder, three-digit numbering. Spec Kit's own
  `.specify/` and `specs/` are carved out, so `speckit.spectra.domain-analyzer` writing
  `.specify/memory/domain-analysis.md` stays compliant — that is context for another command, not a
  deliverable. The point is forward-looking: the roster has a dozen more document producers under
  development, and each one now inherits its output location instead of choosing a new top-level folder.

## [1.5.0] - 2026-08-19

### Changed
- **`speckit.spectra.create-pr` now hard-stops when `gh` is missing or unauthenticated**, instead of
  degrading to a printed manual fallback. The check runs as the first thing after you accept the offer —
  before the constitution is read, before a target branch is derived, before any `git` command — and it
  names which of the two failed, because the remedies differ: install the GitHub CLI, or run
  `gh auth login`. Nothing is mutated on that path, and when `gh` is absent the message no longer prints
  a `gh` command line; the only alternative it names is the GitHub web interface.

  This **reverses the difference recorded in 1.4.0**, where `create-pr` degrading was described as a
  deliberate contrast with `review-pr`. That justification does not survive contact with the two
  failures it was meant to serve. The printed fallback told the user to run `gh pr create` — the command
  they demonstrably did not have — and the duplicate-PR check is itself a `gh` call, so a run without
  `gh` could walk them into a second pull request for a branch that already had one. Both GitHub
  commands now gate identically. What differs is only what each hands over *after* the gate.

- **A refusal after the gate now degrades properly, and says what it changed.** A protected base branch,
  a token without push permission, or a fork restriction is reported with the underlying `git`/`gh`
  message, the manual commands including the derived base branch — runnable, because `gh` is present
  here — and, critically, the mutation state: *nothing reached the remote*, or *the branch is on the
  remote and no pull request exists*. The command previously had no instructions for this case at all,
  even though by then it may already have pushed.

- **A remote that is absent or not on `github.com` is now a stop with a scope statement**, not a
  degradation, and prints no `gh` fallback — there is nothing `gh` can do with a GitLab remote. GitHub
  Enterprise is named as out of scope rather than half-attempted.

- **The pull request body is passed on standard input** (`--body-file -`) rather than as a
  command-line argument, so spec prose carrying backticks, code fences, quotes, and blank lines reaches
  the pull request unaltered. `review-pr` already published review bodies this way.

- **Fork detection is read from the repository, not guessed from the URL.** One
  `gh repo view --json nameWithOwner,isFork,parent,defaultBranchRef,viewerPermission` call replaces the
  previous "if `origin` looks like a fork" heuristic *and* the separate default-branch lookup. Forks and
  multi-remote setups are still resolved by asking, and now for a stated reason: `gh pr list --head`
  rejects `<owner>:<branch>` while `gh pr create --head` accepts it, so an inferred fork flow would
  check for duplicates against one head and open against another.

- **`gh` is declared as the only route to GitHub** in the command's governing rule — no `curl`, no
  direct REST calls — matching `review-pr`.

`gh` remains **optional at the extension level**: `adr`, `brd`, and `domain-analyzer` never touch
GitHub, so requiring it would block installation for users who only want those.

A command changed behaviour, no argument or output contract did, which is why this is a MINOR.

## [1.4.0] - 2026-08-17

### Added
- **`speckit.spectra.review-pr` — a reviewing agent for the last manual gate in the lifecycle.** It
  reviews a GitHub pull request against **the intent and standards the PR carries**: the spec, plan,
  tasks, and ADRs read at the PR's own head revision, plus the constitution and ADRs in force on the
  **base** branch. That is what lets it report a task marked complete but absent from the diff, scope
  no requirement authorized, or a pattern an ADR forbids — none of which a diff-only reviewer can see.

  Two properties define it:

  - **Every finding is anchored and sourced.** A file, a line, and the clause, requirement id, or named
    principle it rests on. A finding that cannot be anchored and sourced is not reported at all.
  - **The human is the filter.** Nothing is pre-selected. The reviewer chooses which findings are
    published and which verdict to submit, sees the exact body first, and gives a final go-ahead before
    anything is posted. An empty selection posts nothing and is a normal outcome. Approving over a
    blocker the reviewer accepted requires a typed confirmation and is recorded in the published review.

  Findings are graded Blocker / Major / Minor / Nit / Question from a fixed rubric so repeated reviews of
  one revision agree, with floors that keep an explicit constitution violation at Major or above and an
  explicit compliance violation at Blocker. Low confidence cannot be a Blocker — it becomes a Question.

  Publication is a single review event through the reviewer's own `gh` authentication. The agent holds no
  credentials, adds no data path, and stores nothing between runs.

  Two behaviours differ from `create-pr` on purpose:

  - **It hard-stops when `gh` is missing or unauthenticated** rather than degrading, because a review's
    value is the analysis and the analysis needs the PR. Failures *after* that gate — a fork
    restriction, insufficient permission — still degrade gracefully to a rendered body for manual
    posting.
  - **It registers no hook.** Review is on demand only, since the reviewer should not be the author.

  GitHub only in this release, and single-body reviews only — line-anchored inline comments are a
  follow-on.

A command was added, which is why this is a MINOR.

## [1.3.1] - 2026-08-09

### Changed
- **The extension description is now the positioning line used everywhere else:** "TELUS Digital -
  Agentic software engineering across the entire SDLC." It previously enumerated the four shipped
  commands, which meant it needed editing every time an agent was added and disagreed with the
  wording on the landing page and in the README. One line, one place, no drift.
- **The Commands table in `README.md` is generated** from the new root `agents-list.json` roster
  rather than maintained by hand. The region is marked with
  `<!-- SPECTRA:GENERATED START id=spectra-readme-commands -->`; everything around it, including the
  four per-agent sections, stays hand-written. Its Effect column is dropped — `effect: read-write` is
  declared once for the extension in `extension.yml`.
- **The PR agent is titled "GitHub (PR)" everywhere.** It previously appeared as `github`, GitHub,
  GitHub (PR), and "GitHub PR delivery" across four documents. Its command is unchanged:
  `speckit.spectra.create-pr`.

No command was added, changed, or removed, which is why this is a PATCH.

## [1.3.0] - 2026-08-08

### Changed
- **Relicensed from MIT to the Apache License 2.0.** Spectra stays free to use, modify, and
  redistribute for any purpose, including commercially. Apache-2.0 adds an explicit patent grant and
  makes attribution enforceable: redistributions and derivative works must retain the copyright
  notice, ship the `LICENSE` and `NOTICE` files, and state which files were changed
  (§4(b)–4(d)).

### Added
- `NOTICE` — the attribution notice that downstream redistributors are required to carry forward
  under Apache-2.0 §4(d). It now ships inside the extension package.

## [1.2.0] - 2026-07-14

### Added
- **`speckit.spectra.brd`** — a Requirements & Discovery-phase command that transforms a raw business
  requirement (inline text or a `.docx`/`.pdf`/`.md`/`.txt` document) into a structured,
  specify-ready BRD written under `/brds`. It reads project context to ground the document, asks up to
  five clarifying questions only when the requirement has material gaps, never invents requirements
  (genuine unknowns become Open Questions), and hands off to the Spec Kit **specify** command. Its only
  write is the BRD file.
- Bundled the canonical BRD template as `templates/brd-template.md` so the command produces the same
  structure in any installed project.

## [1.1.0] - 2026-07-09

### Changed
- Consolidated the previously separate `adr`, `domain-analyzer`, and `github` extensions into a
  single `spectra` extension. Every capability is now a command under the unified `speckit.spectra.*`
  namespace, matching Spec Kit's `speckit.<extension-id>.<command>` rule (the extension `id` is
  `spectra`):
  - `speckit.adr.new` → `speckit.spectra.adr`
  - `speckit.domain-analyzer.analyze` → `speckit.spectra.domain-analyzer`
  - `speckit.github.create-pr` → `speckit.spectra.create-pr`
- Install once with `specify extension add spectra` to get all three commands. The `after_implement`
  hook now invokes `speckit.spectra.create-pr`.

### Commands
- **`speckit.spectra.adr`** — Create a context-aware Architecture Decision Record grounded in the
  codebase, prior ADRs, and the project constitution; asks up to five clarifying questions and writes
  the ADR under `Docs/ADR/`.
- **`speckit.spectra.domain-analyzer`** — Infer the project's business domain and write an opt-in
  proposal of evidence-backed candidate guardrails to `.specify/memory/domain-analysis.md` for SME
  review and handoff to `/speckit-constitution`. Never edits the constitution or source.
- **`speckit.spectra.create-pr`** — Offer to open a correctly-targeted GitHub PR for the current spec
  branch after `implement`, deriving the base branch from the promotion strategy, confirming before
  any push, and returning the PR URL — with a graceful manual fallback when `gh`, the remote, or the
  network is unavailable.
